# Integration Guide

## 1. Batch naming (`utils/batchName.js`)
Copy to `frontend/src/utils/batchName.js`.

In `BatchTable.jsx`, replace the `batch_name` column:
```jsx
import { buildBatchDisplayName } from "../../../utils/batchName";
...
{
    headerName: "ชื่อรุ่น",
    pinned: "left",
    flex: 2,
    cellClass: "font-semibold text-slate-900",
    valueGetter: (p) => buildBatchDisplayName(p.data),
},
```
Apply the same `buildBatchDisplayName` wherever `batch_name` is displayed in
comboboxes (`BatchesPage.jsx`, `StudyGroupsPage.jsx` breadcrumb,
`FinanceVerificationPage.jsx`/`RegistrarEnrollmentsPage.jsx` batch options) —
swap `label: b.batch_name` for `label: buildBatchDisplayName(b)`.

If a `batch_sequence` running-number column doesn't yet exist on `batches`,
add it via migration; otherwise the display falls back to `batch_no`.

## 2. TimeSlotBadge (`components/common/TimeSlotBadge.jsx`)
Copy to `frontend/src/components/common/TimeSlotBadge.jsx`.

In `CourseCard.jsx`, next to the title:
```jsx
import TimeSlotBadge from "../../../components/common/TimeSlotBadge";
...
<div className="mb-2 flex flex-wrap items-center gap-2">
    <span className="rounded-md bg-indigo-50 px-2 py-0.5 text-xs font-bold text-indigo-600">
        {course.subject_code || course.subjects?.[0]?.subject_code}
    </span>
    <TimeSlotBadge timeCode={course.time_code} timeRange={course.time_range} size="sm" />
</div>
```
Same in `CourseListRow.jsx` next to the course name. Requires `time_code`/
`time_range` to be included in the public study-group mapping
(`public.service.js#mapGroup` — join `time_slots` via a `time_code` column
on `study_groups`, or parse from `group_code` as `GroupFormPanel` already
does via `extractTimeCodeFromGroupCode`).

## 3. Live age + DateSelector
Copy `components/common/DateSelector.jsx` and `utils/ageUtils.js`,
`features/public/components/BirthDateField.jsx`.

In `ApplicantFormFields.jsx` (both public and registrar copies), replace:
```jsx
<MaskedDateInput value={formData.birth_date} onChange={...} className={inputCls} />
```
with:
```jsx
<BirthDateField value={formData.birth_date} onChange={(iso) => setFormData((p) => ({ ...p, birth_date: iso }))} />
```

## 4. Stepper relabeling
`Stepper.jsx` already takes a `steps` array — in `RegistrationPage.jsx`:
```jsx
const STEP_LABELS = [
    "ข้อมูลผู้สมัครและเอกสาร",
    "ช่องทางชำระเงิน",
    "ตรวจสอบข้อมูลก่อนส่ง",
];
```

## 5. Resubmit workflow
Already implemented end-to-end in `StatusCheckModal.jsx` → `ResubmitPanel`,
wired to `resubmitApplication` (public API) and backend
`resubmitApplicationService`. No changes needed — confirmed working per
current codebase.

/**
 * Patch for backend/src/features/public/public.service.js
 * ─────────────────────────────────────────────────────────────────────────
 * Adds time_code (parsed from group_code, same convention as
 * GroupFormPanel's extractTimeCodeFromGroupCode) and joins time_slots for
 * time_range, so the frontend TimeSlotBadge can render without an extra
 * request.
 *
 * 1) Add `time_slots` join to GROUP_SELECT (append after study_group_subjects):
 */
export const GROUP_SELECT_ADDITION = `
  group_code
`; // group_code already selected — time_code is derived client-side in mapGroup

/**
 * 2) In mapGroup(row), add:
 */
function extractTimeCodeFromGroupCode(groupCode) {
    if (!groupCode) return "";
    const match = /[ชบคพ]/.exec(groupCode);
    return match ? match[0] : "";
}

// Inside mapGroup return object, add:
//   time_code: extractTimeCodeFromGroupCode(row.group_code),
//
// If you want the full time_range text too (not just the badge deriving it
// from start hour), fetch time_slots once in the controller/service layer
// and map time_code -> time_range, e.g.:
//
//   const { data: slots } = await supabase.from('time_slots').select('time_code, time_range');
//   const rangeByCode = Object.fromEntries((slots || []).map(s => [s.time_code, s.time_range]));
//   ...
//   time_range: rangeByCode[extractTimeCodeFromGroupCode(row.group_code)] || null,
